#!/bin/bash

# Build script for Bajaj Java App
# This script will compile and package the Spring Boot application into an executable JAR

set -e  # Exit on any error

echo "========================================="
echo "Building Bajaj Java App"
echo "========================================="

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "Error: Maven is not installed or not in PATH"
    echo "Please install Maven 3.6 or higher to build this project"
    exit 1
fi

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed or not in PATH"
    echo "Please install Java 17 or higher to build this project"
    exit 1
fi

# Check Java version
JAVA_VERSION=$(java -version 2>&1 | grep -oP 'version "([0-9]+)' | grep -oP '[0-9]+' | head -1)
if [ "$JAVA_VERSION" -lt 17 ]; then
    echo "Error: Java version $JAVA_VERSION is not supported"
    echo "Please install Java 17 or higher"
    exit 1
fi

echo "✓ Java version: $JAVA_VERSION"
echo "✓ Maven version: $(mvn -version | head -1)"
echo ""

# Clean any previous builds
echo "Cleaning previous builds..."
mvn clean

echo ""
echo "Compiling and packaging application..."

# Build the application
mvn package -DskipTests

# Check if build was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "========================================="
    echo "✓ Build completed successfully!"
    echo "========================================="
    echo ""
    echo "Executable JAR file created at:"
    echo "  $(pwd)/target/bajaj-java-app-1.0.0.jar"
    echo ""
    echo "To run the application:"
    echo "  java -jar target/bajaj-java-app-1.0.0.jar"
    echo ""
    echo "JAR file size: $(du -h target/bajaj-java-app-1.0.0.jar | cut -f1)"
    echo "========================================="
else
    echo ""
    echo "✗ Build failed!"
    echo "Please check the error messages above"
    exit 1
fi
