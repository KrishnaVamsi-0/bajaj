# Bajaj Java App

A Spring Boot application that submits SQL query data to the Bajaj Finserv Health API endpoint.

## Overview

This application is designed to:
1. Send a registration request to the Bajaj API to generate a webhook URL and access token
2. Submit a SQL query solution using the obtained credentials
3. Handle the API response and provide feedback

## Prerequisites

- Java 17 or higher
- Maven 3.6 or higher

## Building the Application

To build the executable JAR file, run:

```bash
./build.sh
