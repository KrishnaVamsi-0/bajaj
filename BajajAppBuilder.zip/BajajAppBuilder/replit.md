# Overview

This is a Java Spring Boot application that integrates with the Bajaj Finserv Health API. The application performs a two-step process: first registering with the API to obtain authentication credentials (webhook URL and access token), then submitting SQL query solutions using those credentials. It's designed as a simple API client that handles the complete flow of registration and data submission to Bajaj's external service.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Application Framework
- **Spring Boot**: Chosen as the primary framework for rapid development and built-in features like dependency injection, auto-configuration, and embedded server support
- **Java 17+**: Modern Java version providing enhanced performance and language features
- **Maven**: Build tool for dependency management and project structure standardization

## API Integration Pattern
- **Two-Phase API Flow**: The application implements a sequential API interaction pattern where registration must occur before data submission
- **Credential Management**: Temporary storage of webhook URL and access token between API calls
- **REST Client Architecture**: Uses Spring's HTTP client capabilities to communicate with external Bajaj API endpoints

## Build and Deployment
- **Executable JAR**: Application packages into a single executable JAR file for easy deployment
- **Shell Script Build**: Automated build process using Maven wrapper for consistent builds across environments

## Error Handling Strategy
- **API Response Processing**: Built to handle both successful responses and error conditions from the Bajaj API
- **Feedback System**: Provides user feedback on the status of both registration and submission processes

# External Dependencies

## Primary Integration
- **Bajaj Finserv Health API**: External REST API service that requires registration and provides webhook URLs for data submission

## Build Tools
- **Maven**: Dependency management and build lifecycle
- **Maven Wrapper**: Ensures consistent Maven version across different environments

## Runtime Dependencies
- **Spring Boot Starter Web**: Provides REST client capabilities and embedded server
- **Spring Boot Core**: Framework foundation with dependency injection and auto-configuration
- **Jackson**: JSON processing for API request/response handling (typically included with Spring Boot Web)